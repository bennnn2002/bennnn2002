module.exports = {
    app: {
        px: '+',
        token: 'MTIzMTU2NzQ4NTQ2ODQxNDAxMg.G4BT7c.r7OKuvD8Erc_dzpFKQOLzRYKhWiuHXf4moHsSE',
        owners: '1138136714246893648',
        funny: '1138136714246893648',
        color: '#FF0000',
        footer: 'By Benji€',
        maxserver: '1',
        maxVol: '150',
        everyoneMention: false,
        hostedBy: true,
        discordPlayer: {
            ytdlOptions: {
                quality: 'highestaudio',
                highWaterMark: 1 << 25
            }
        }
    }
}